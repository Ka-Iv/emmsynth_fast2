function emmsynth_fast

%EMMSYNTH_FAST uses tensor-product needlets for fast computation of
% the values of the magnetic field gradient at the points from the file
% 'scattered_points.dat' in a given decimal year and a given magnetic
% model (EMM2015 or EMM2017). The gradient is defined in the six files 
% 'emm2015_*.bin' or 'emm2017_*.bin' (depending on the model), containing
% its components weighted values at regular grids on confocal ellipsoids.
%
% INPUT: 
% 1. FORTRAN unformated data file 'emm201?_*.bin' with the weighted
%    values at regular grids on confocal ellipsoids.
% 2. free format file 'scattered_points.dat' with point's geodetic
%    coordinates: latitude, longitude (in degrees) and height (in meters).
% 3. The chosen magnetic model.
% 4. The 'year' when the model is computed.
%
% OUTPUT: 
% 1. free format file 'scattered_points_values.dat' with point's geodetic
%    latitude, longitude, (in degrees), height (in meters) and the values
%    of ten magnetic field components.
%
% Notes.
%	1. Geodetic coordinates must define points with height 
%    ranging from -415 m to 1,000,000 m.
% 2. The 'year' is a decimal number between 2015 and 2020 for EMM2015 or
%    between 2017 and 2022 for EMM2017.

% Version: November 2018
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg


%% model and year input and check
model=input('Which model to use? (Enter 1 for EMM2015 or 2 for EMM2017): ');
switch model
  case 1
    modeldegree=740;
    s2_X='emm2015_Xp.bin';
    s2_XSV='emm2015_XpSV.bin';
    s2_Y='emm2015_Yp.bin';
    s2_YSV='emm2015_YpSV.bin';
    s2_Z='emm2015_Zp.bin';
    s2_ZSV='emm2015_ZpSV.bin';
    year0=2015;
    year1=2020;
  case 2
    modeldegree=790;
    s2_X='emm2017_Xp.bin';
    s2_XSV='emm2017_XpSV.bin';
    s2_Y='emm2017_Yp.bin';
    s2_YSV='emm2017_YpSV.bin';
    s2_Z='emm2017_Zp.bin';
    s2_ZSV='emm2017_ZpSV.bin';
    year0=2017;
    year1=2022;
  otherwise
      error('emmsynth_fast:model','wrong input"');
end

year=input('Enter decimal year for geomagnetic computations: ');
if (year<year0)||(year>year1)
  error('emmsynth_fast:year',['The year must be decimal number between ',num2str(year0),' and ',num2str(year1)]);
end
dt=year-year0;

time0=clock;
TTime1=0;
TTime2=0;
TTime3=0;


%% Earth constants
% wgs84_constants
ae = 6378137.0; 
inv_flat=298.257223563;
be = ae*(1-1/inv_flat);
E=realsqrt((ae-be)*(ae+be));

% am=6371200; %m; geomagnetic reference radius

% displacement for the lowest Earth surface point wrt reference ellipsoid
db=-417;         %reference ellipsoid displacement in meters $b_0=b_e-417$
b0=be+db; 

%% parameters

s1='scattered_points.dat'; %scattered points input file name
% s2_X='emm2017_Xp.bin';
% s2_XSV='emm2017_XpSV.bin';
% s2_Y='emm2017_Yp.bin';
% s2_YSV='emm2017_YpSV.bin';
% s2_Z='emm2017_Zp.bin';
% s2_ZSV='emm2017_ZpSV.bin';
s3='scattered_points_values.dat'; %point and value output file name

NN=740;  %grid papameter
tau=2;
ind_zero=[9;9;0];     %extended values parameters   
ndelta3=2;              %semi-order of Lagrange interpolation 

%% regular grid dimensions
KK=round((1+tau/2)*NN)+1;  
LL2=round((1+tau/2)*NN);
LL=2*LL2;   

h1=pi/(KK-1);
h1i=1/h1;
h2=pi/LL2;
h2i=1/h2;

%% extended values parameters

% extended ellipsoid nodal set dimensions
KKext=KK+2*ind_zero(1)-1;  
LLext=LL+2*ind_zero(2)-1;

% generating heights
ht=0.020124185;
NumHeights=45;


%% kernel parameters
ParKer(1)=740;       %degree of the polynomials reproduced by the needlet kernel
ParKer(2)=tau;       %needlet parameter
ParKer(3)=0.430729833773221*10^(-5); %target accuracy to be achieved by discrete needlet operator
ParKer(4)=2;       % type of the cutoff function
ParKer(5)=500;     % step refinement parameter
ParKer(6)=2;       % Lagrange interpolation of degree 2*ParKer(6)-1 for fast kernel evaluation
ParKer(7)=pi;      % radius of the "essential support" of the needlet kernel
ParKer(8)=0;       % "logical", if ParKer(8)=0, then  ParKer(7) is computed in 'kernel_basic'
ParKer(9)=0;       % step of the Lagrangean (almost) equally spaced interpolation knots
ParKer(10)=1;      % number of removed trailing negligible coefficients 

%% cubature parameters
ParCub(1)=1; % quadrature type in co-latitude direction
ParCub(2)=KK; % number of knots in [0,pi] of co-latitude quadrature
ParCub(3)=LL; % number of equally spaced knots in [0,2*pi) of longitude quadrature
ParCub(4)=0; % degree of exactness of the tensor product cubature
ParCub(5)=0; % parity of ParCub(2)
ParCub(6)=2; % parity of ParCub(3)

%% memory parameters 
ParMem(4)=1*10^4;  % number of simultaneously computed polynomial values

%% formation of parameters for trigonometric needlet kernels 
ParKer1=ParKer; %parameters for latitude kernel
ParKer1(3)=ParKer1(3)/2;
[ParKer1,Kernel_y1]=kernel_basic_trig(ParKer1);

ndelta1=floor(ParKer1(7)*h1i)+1; % it is necessary to have ndelta1 <= ind_zero(1)

index1=(1:2*ndelta1);

% equal kernels in co-latitude and longitude directions
ParKer2=ParKer1;
Kernel_y2=Kernel_y1;

ndelta2=floor(ParKer2(7)*h2i)+1; % it is necessary to have ndelta2 <= ind_zero(2)
index2=(1:2*ndelta2);

%% formation of parameters for algebraic Lagrange kernel 
h3=ht;
h3i=1/h3;
index3=(1:2*ndelta3);

%% weighted values of the geopotential quantity at regular grid points
time3=clock;

valueXext=zeros(KKext,LLext,NumHeights);
valuew=zeros(KKext,LLext,NumHeights);
fid1 = fopen(s2_X, 'r', 'l');
for nu=1:NumHeights
  nw1=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  wb=fread(fid1, [KKext,LLext], 'double');
  nw2=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  valueXext(:,:,nu)=wb;
end
fclose(fid1);
fid1 = fopen(s2_XSV, 'r', 'l');
for nu=1:NumHeights
  nw1=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  wb=fread(fid1, [KKext,LLext], 'double');
  nw2=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  valuew(:,:,nu)=wb;
end
fclose(fid1);
valueXext=valueXext+dt*valuew;

valueYext=zeros(KKext,LLext,NumHeights);
valuew=zeros(KKext,LLext,NumHeights);
fid1 = fopen(s2_Y, 'r', 'l');
for nu=1:NumHeights
  nw1=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  wb=fread(fid1, [KKext,LLext], 'double');
  nw2=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  valueYext(:,:,nu)=wb;
end
fclose(fid1);
fid1 = fopen(s2_YSV, 'r', 'l');
for nu=1:NumHeights
  nw1=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  wb=fread(fid1, [KKext,LLext], 'double');
  nw2=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  valuew(:,:,nu)=wb;
end
fclose(fid1);
valueYext=valueYext+dt*valuew;

valueZext=zeros(KKext,LLext,NumHeights);
valuew=zeros(KKext,LLext,NumHeights);
fid1 = fopen(s2_Z, 'r', 'l');
for nu=1:NumHeights
  nw1=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  wb=fread(fid1, [KKext,LLext], 'double');
  nw2=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  valueZext(:,:,nu)=wb;
end
fclose(fid1);
fid1 = fopen(s2_ZSV, 'r', 'l');
for nu=1:NumHeights
  nw1=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  wb=fread(fid1, [KKext,LLext], 'double');
  nw2=fread(fid1, 1, 'uint32'); %#ok<NASGU>
  valuew(:,:,nu)=wb;
end
fclose(fid1);
valueZext=valueZext+dt*valuew;

TTime3=TTime3+etime(clock,time3);
clear valuew wb

%% scattered points for solid spherical polynomial evaluation
time2=clock;
%
pt=dlmread(s1);
npt=size(pt,1);

% checking evaluation point coordinates
if ~isreal(pt)
  error('emmsynth_fast:pZ','point coordinates must be real');
end
if (any(pt(:,1)<-90))||(any(pt(:,1)>90))
  error('emmsynth_fast:pt','latitude must be between -90 and 90 degrees');
end
if (any(pt(:,2)<-180))||(any(pt(:,2)>180))
  error('emmsynth_fast:pt','longitude must be between -180 and 180 degrees');
end
if (any(pt(:,3)<-415))||(any(pt(:,3)>1000000))
  error('emmsynth_fast:pt','hight must be between -415 m and 1,000,000 m');
end
% 

values=zeros(npt,13); % output array
values(:,1:3)=pt;

point=zeros(npt,3); % work array
point(:,2)=pt(:,2)*pi/180;
ind=point(:,2)<0;
point(ind,2)=point(ind,2)+2*pi;
phi=pt(:,1)*pi/180;
[phiprime,point(:,3)]=gd2gc(phi,pt(:,3),ae,be);
point(:,1)=pi/2-phiprime; %co-latitude

clear pt
TTime2=TTime2+etime(clock,time2);


%% evaluation - start
time1=clock;

%from spherical to ellipsoidal coordinates
[point(:,1),point(:,2),point(:,3)]=sphere2ellips(point(:,1),point(:,2),point(:,3),E);

% checking evaluation point coordinates
point(:,3)=point(:,3)-b0; %heights
h_end=floor(b0/(1-(ht*(NumHeights-ndelta3))^4/4)-b0);
if (any(point(:,3)<0))||(any(point(:,3)>h_end))
  error('emmsynth_fast:point',horzcat...
    (['the hight above reference ellipsoid must be between -0.415 and ',num2str(h_end/1000),' km']));
end
point3_t=(4*point(:,3)./(b0+point(:,3))).^(1/4);

%% evaluation - general loop
nloop=ceil(npt/ParMem(4));
for iloop=1:nloop
  if (iloop<nloop)
    point1w=point((iloop-1)*ParMem(4)+1:iloop*ParMem(4),1);
    point2w=point((iloop-1)*ParMem(4)+1:iloop*ParMem(4),2);
    point3w=point3_t((iloop-1)*ParMem(4)+1:iloop*ParMem(4));
  else
    point1w=point((iloop-1)*ParMem(4)+1:npt,1);
    point2w=point((iloop-1)*ParMem(4)+1:npt,2);
    point3w=point3_t((iloop-1)*ParMem(4)+1:npt);
  end

%% neighbourhood and distances formation
  switch ParCub(1)
    case 1
      n1=floor(point1w*h1i);
      [indw1,indw2]=meshgrid(index1,n1);
      index1w=indw1+indw2-ndelta1;
      index1t=index1w+ind_zero(1);
      tt1=abs(index1w*h1-point1w(:)*ones(1,2*ndelta1));   
      clear indw1 indw2 index1w
    case 2
      n1=floor(point1w*h1i-.5);
      [indw1,indw2]=meshgrid(index1,n1);
      index1w=indw1+indw2-ndelta1;
      index1t=index1w+ind_zero(1)+1;
      tt1=abs((index1w+.5)*h1-point1w(:)*ones(1,2*ndelta1));   
      clear indw1 indw2 index1w
  end
  
  n2=floor(point2w*h2i);
  [indw1,indw2]=meshgrid(index2,n2);
  index2w=indw1+indw2-ndelta2;
  index2t=index2w+ind_zero(2);
  tt2=abs(index2w*h2-point2w(:)*ones(1,2*ndelta2));   
  clear indw1 indw2 index2w

  n3=floor(point3w*h3i);
  t3=point3w*h3i-n3;   
  [indw1,indw2]=meshgrid(index3,n3);
  index3w=indw1+indw2-ndelta3;
  index3t=abs(index3w+ind_zero(3))+1;
  clear indw1 indw2 index3w

%% kernel evaluations
  ker_val1=kernel_values(ParKer1,Kernel_y1,tt1);
  ker_val2=kernel_values(ParKer2,Kernel_y2,tt2);
  ker_val3=lagrange_basis(2*ndelta3,t3);
  
%% needlet evaluation
  workX=0*ker_val3;
  workY=workX;
  workZ=workX;
  for k=1:length(point1w)
    for j=1:2*ndelta3
      workX(k,j)=ker_val1(k,:)*valueXext(index1t(k,:),index2t(k,:),index3t(k,j))*ker_val2(k,:)';
      workY(k,j)=ker_val1(k,:)*valueYext(index1t(k,:),index2t(k,:),index3t(k,j))*ker_val2(k,:)';
      workZ(k,j)=ker_val1(k,:)*valueZext(index1t(k,:),index2t(k,:),index3t(k,j))*ker_val2(k,:)';
    end
  end
  values((iloop-1)*ParMem(4)+1:(iloop-1)*ParMem(4)+length(point1w),4)=sum(workX.*ker_val3,2);
  values((iloop-1)*ParMem(4)+1:(iloop-1)*ParMem(4)+length(point1w),5)=sum(workY.*ker_val3,2);
  values((iloop-1)*ParMem(4)+1:(iloop-1)*ParMem(4)+length(point1w),6)=sum(workZ.*ker_val3,2);
end %for iloop

%% computing quantities in the ellipsoidal reference frame

% rotating geocentric to ellipsoidal reference frame
dphi=(phiprime-phi);
cdphi=cos(dphi);
sdphi=sin(dphi);
values(:,7)=values(:,4).*cdphi-values(:,6).*sdphi;% X north component
values(:,8)=values(:,5);                            % Y east component
values(:,9)=values(:,4).*sdphi+values(:,6).*cdphi;% Z down component

% evaluating the remaining components of the field  
H2=values(:,7).^2+values(:,8).^2;
values(:,10)=realsqrt(H2);                       % H horizontal intensity
values(:,11)=realsqrt(H2+values(:,9).^2);      % F total intensity
values(:,12)=atan2(values(:,9),values(:,10));% I inclination
values(:,13)=atan2(values(:,8),values(:,7)); % D declination

TTime1=TTime1+etime(clock,time1);

%% evaluation - end

%% output

time4=clock;
fid=fopen(s3,'wt');
fprintf(fid, [repmat('%20.14f',1,2),'%16.8f',repmat('%12.4f',1,8),repmat('%12.8f',1,2),'\n'], values');
fclose(fid);
TTime4=etime(clock,time4);
TTime0=etime(clock,time0);

%% statistics

disp('---------------------------------------------------------------')
switch model
  case 1
    disp('        Program:  emmsynth_fast,       Model: EMM2015')
  case 2
    disp('        Program:  emmsynth_fast,       Model: EMM2017')
end
disp(['   Evaluation year:            = ' num2str(year)])
disp('---------------------------------------------------------------')
disp(['   Total time                  = ' num2str(TTime0) ' CPU seconds'])
disp(['   Grid values load time       = ' num2str(TTime3) ' CPU seconds'])
disp(['   Coordinates load time       = ' num2str(TTime2) ' CPU seconds'])
disp(['   Synthesis time              = ' num2str(TTime1) ' CPU seconds'])
disp(['   Values write time           = ' num2str(TTime4) ' CPU seconds'])
disp(['   Total number of points      = ' num2str(npt)])
disp(['   Retrieved points per second = ' num2str(npt/TTime1)])
disp('---------------------------------------------------------------')


%%
function [ParKer,Y,X]=kernel_basic_trig(ParKer)
%KERNEL_BASIC_TRIG computes the values of the trigonometric kernel at
%equally spaced knots
%
% The code evaluate via Clenshaw recurrence the even trigonometric kernel
% $y(x)=\sum_{n=0}^\infty \varphi(n/N) \cos(nx)$
% for $\varphi(0)=.5$; $\varphi(t)=1, 0<t\le 1$; and $0\le\varphi(t)\le 1$, 
% $1<t\le 1+\tau$, where $N=ParKer(1)$ and $\tau=ParKer(2)$.
% The type of the cutoff function $\varphi$ is given by ParKer(4).
% The knots  X, X(k)=(k-nu)*h, k=1,2,..., (nu=ParKer(6))   are equally 
% spaced with step  h=ParKer(9) in the interval [(1-nu)*h,delta+nu*h]
% and delta=ParKer(7).
%
% INPUT: 
% 1. ParKer -- see Parmeters. The code uses all elements of  ParKer.
% OUTPUT: 
% 1. ParKer -- see Parmeters
% 2. Y - vector with the values of the kernel at the knots  X
% 3. X - vector with the values of the knots
%
% Notes. 
% 1. Y  is of the same length as  X.
% 2. ParKer is an output variable because the code defines 
%   a) ParKer(9) as ParKer(9)=pi/(Degree*ParKer(5) )with 
%      Degree=ParKer(1)+ceil(ParKer(1)*ParKer(2))-ParKer(10);
%   b) ParKer(7) (if ParKer(8)=0).
% 3. If ParKer(8)=0 then ParKer(7) is the output of 'length_supp_trig' plus
% pi/(Degree+ParKer(1)).

% Version: October 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

k0=ParKer(1);
N=ceil(ParKer(1)*ParKer(2));
Degree=N+k0-ParKer(10);  %total degree of polynomial kernel
m=-log10(ParKer(3));

%coefficients formation
switch ParKer(4)
  case 1
    b=round(0.8722*m-1.5416);
    wc=cut_off(N,1,b);
  case 2
    b=(58*m-7)/25;
    wc=cut_off(N,2,b);
end
Coef=ones(Degree+1,1);             
Coef(max(k0,0)+1:Degree+1)=wc(N+min(k0,0)+1:-1:ParKer(10)+1);
Coef(1)=Coef(1)/2;

%evaluation of delta
if (ParKer(8)==0)
  ParKer(7)=length_supp_trig(Coef,ParKer(3),3)+pi/(k0+Degree); 
else
  ParKer(7)=length_supp_trig(Coef,ParKer(3),3); 
end

%computation of basic values
ParKer(9)=pi/(Degree*ParKer(5));  %step of the grid;
Np0=ceil(ParKer(7)/ParKer(9));
X=(1-ParKer(6):Np0+ParKer(6))'*ParKer(9); %equally spaced knots
Y=clenshaw_trig(Coef,0*Coef,X);
for k=1:ParKer(6)-1
  Y(k)=Y(2*ParKer(6)-k);
end

%%
function y=cut_off(R,tip,b)
%CUT_OFF computes the values of a cutoff function
%
% The continuous cutoff function  $y(t)=\phi(t)$ satisfies
% $\phi : [0,1]\to[0,1]$, $\phi(0)=0, \phi(1)=1$.
%
% INPUT: 
% 1. R is the number of equal intervals on which [0,1] is divided
%    in order to form the knots t(k)=(k-1)/R, k=1,2,...,R+1.
% 2. tip  is the type of the generating cutoff function, 
% 3. b  is a parameter of the cutoff function.
% tip = 1: $\phi(t)=\int_0^t (\pi/2)*\sin^{2*b+1}(\pi v) dv *(2*b+1)!!/(2*b)!!$
% tip = 2: $\phi(t)=\kappa \int_0^t \exp{2*b*\sqrt{v*(1-v)}} dv$ 
%          with $\kappa =( \int_0^1 \exp{2*b*\sqrt{v*(1-v)}} dv)^{-1}$.
%
% OUTPUT: 
% 1. y  the values of the cutoff function at the knots  t.
%
% Notes. 
% 1. In the spherical case for: 
%  a) tip=1 set  b(m)=4,5,5,6,7,8 for m=5,6,7,8,9,10, eps=10^(-m).
%  b) tip=2 set $b(m)=2.4*m+1.7-0.1*\tau+0.1*(\tau-3)_+$ for m=5,6,7,8,9,10, eps=10^(-m)
% 2. In the trigonometric case for
%  a) tip=1 set  
%  b) tip=2 set $b(m)=(58*m-7)/25$ for m=5,6,7,8,9,10,11, eps=10^(-m)

% Version: May 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

switch tip
  case 1
    tt1=(0:R)'/R;
    S2=sin(pi*tt1).^2;
    y=ones(R+1,1);
    for k=b:-1:1
      y=1+y.*S2*(1-1./(2*k));
    end
    y=1/2-y.*cos(pi*tt1)/2;
    y=max(y,0);
    y=min(y,1);
    x=1;
    y(R+1)=1;
    for k=R:-1:1
      if (y(k)>x), y(k)=x; end
      x=y(k);
    end
    y(1)=0;
    R2=floor(R/2);
    if (2*R2==R)
      y(R2+1)=0.5; 
      y(R+1:-1:R2+2)=1-y(1:R2);
      y(1:R2)=1-y(R+1:-1:R2+2);
    else
      y(R+1:-1:R2+2)=1-y(1:R2+1);
      y(1:R2+1)=1-y(R+1:-1:R2+2);
    end  
  case 2
    x=0:1/R:1;
    y0= exp(b*sqrt(1-x.^2));
    R2=floor(R/2);
    y1=y0(R+1-2*R2:2:R-1)+4*y0(R+2-2*R2:2:R)+y0(R+3-2*R2:2:R+1);
    y2=zeros(1,R2+1);
    y2(2:R2+1)=y1;
    if ~(R==2*R2)
        y2(1)=2*y0(1)+y0(2);
    end
    y3=cumsum(y2);
    y4=y3/(2*y3(end));
    y=zeros(R+1,1);
    y(R-R2+1:R+1)=0.5+y4';
    y(R2+1:-1:1)=0.5-y4';
end

%%
function delta=length_supp_trig(C,Epsilon,Digits)
%LENGTH_SUPP_TRIG finds the interval [0,delta], where an even polynomial is
%supported. 
%
% For $f(t)=\sum_{k=0}^Degree C_k \cos(kt)$, Degree=length(C),
% the function gives the smallest number  delta, such that
% $\int_\delta^\pi |f| \le Epsilon |\int_0^\pi f| = \pi*|C_0|*Epsilon$.
%
% INPUT: 
%	1. C is the polynomial coefficient vector.
%	2. Epsilon is the accuracy of the "support".
%	3. Digits is the the number of significant digits in  delta.
%
% OUTPUT: 
% 1.delta  is the the length of the "support".
%
% Notes. 
% 1. If C(1)=0, then  delta  is the smallest number satisfying 
% $\int_\delta^{\pi} |f(t)|\,dt\le \pi\epsilon$.
% 2. The following conditions has to be met: 
%  a) 1 <= Degree <= 1000000;
%  b) Epsilon is real, 0 < Epsilon < 1;
%  c) Digits is an integer, 2 <= Digits <= 5. Usually Digits=3.

% Version: October 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

C=C(:);
S=0*C;
Degree=length(C);
if (Degree<1)||(Degree>1000000)
  error('LENGTH_SUPP_TRIG:Degree','The polynomial degree must be less than 1 000 000.')
end
if ~isreal(Epsilon)||(Epsilon<=0) || (Epsilon>=1)
  error('LENGTH_SUPP_TRIG:Epsilon','Presision Epsilon is a real number between 0 and 1.')
end
if ~isreal(Digits)||(Digits<2) || (Digits>5)
  error('LENGTH_SUPP_TRIG:Digits','The number of significant digits is between 2 and 5.')
end

thresh=pi*Epsilon;
if (C(1)~=0), thresh=thresh*abs(C(1)); end
kappa=2*log2(Degree/Epsilon);
h0=10^(-Digits-1);
logh0=log(1-h0);
m=floor(log(1/2)/logh0);

a0=pi;
cond=true;
sum0=0;
kk=0;
while cond && (kk<kappa)
  kk=kk+1;
  loga0=log(a0);
  x=exp((0:m)'*logh0+loga0);
  y=abs(clenshaw_trig(C,S,x));
  sum0=sum0 +y(1)*(x(1)-x(2))/2+y(m+1)*(x(m)-x(m+1))/2;
  sum0=sum0 +sum(y(2:m).*(x(1:m-1)-x(3:m+1)))/2;
  if sum0>thresh
    cond=false;
  else
    a0=x(m+1);
  end
end

k=m+2;
while sum0>thresh
  k=k-1;
  sum0=sum0 -(y(k-1)+y(k))*(x(k-1)-x(k))/2;
end

if (kk<kappa)
  delta=x(k-1);
else
  delta=0;
end

%%
function y=clenshaw_trig(C,S,theta)
%CLENSHAW_TRIG evaluates trigonometric polynomials by their coefficients
% $y(\theta)=\sum_{r=0}^{N-1} (C_r\cos(r\theta)+S_r\sin(r\theta))$.
% using Newbery modification of Clenshaw recurrence [1].
% INPUT: C, S - polynomial coefficient vectors
%        theta - matrix of the independent variable
% OUTPUT: y - matrix with the polynomial values
% 
% Notes: 1. C  and  S  are vectors of the same length. 
%           C(r+1)  contains $C_r$, S(r+1) contains $S_r$. 
% 2. Polynomial degree  N-1  is calculated as \verb#length(C)-1#.
% 3. S(1)  is not used in computation because $S_0\sin(0\theta)=0$
% 4. y  is of the same size as  theta.
%
% [1] A. C. R. Newbery, Error Analysis for Fourier Series Evaluation,
% Mathematics of Computation, 27, 123, (1973), 639-644

% Version: October 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

%coefficients check
C=C(:);
S=S(:);
N=length(C);
if (N~=length(S))
  error('CLENSHAW_TRIG:coefficients','Coefficient vectors C and S must be of the same length!.')
end

%variable change 0
shape_y=size(theta);
t0=theta(:);
y=0*t0;
t0=mod(t0,2*pi);

%variable change 1
ind1=abs(sin(t0))>=sin(pi/4);
t1=t0(ind1);

%Clenshaw reccurence 1
u1=0*t1;
u2=0*t1;
ct1=cos(t1);
for m=N:-1:2
  u3=u2;
  u2=u1;
  u1=(C(m)+2*ct1.*u2)-u3;
end
y1=(C(1)+ct1.*u1)-u2;

u1=0*t1;
u2=0*t1;
for m=N:-1:2
  u3=u2;
  u2=u1;
  u1=(S(m)+2*ct1.*u2)-u3;
end
y(ind1)=y1+sin(t1).*u1;

%variable change 2
ind2=~ind1;
t2=t0(ind2);

C2=C;
S2=-S;

C2(2:4:end)=S(2:4:end);
S2(2:4:end)=C(2:4:end);

C2(3:4:end)=-C(3:4:end);
S2(3:4:end)=S(3:4:end);

C2(4:4:end)=-S(4:4:end);
S2(4:4:end)=-C(4:4:end);

%Clenshaw reccurence 2
u1=0*t2;
u2=0*t2;
ct2=sin(t2);
for m=N:-1:2
  u3=u2;
  u2=u1;
  u1=(C2(m)+2*ct2.*u2)-u3;
end
y2=(C2(1)+ct2.*u1)-u2;

u1=0*t2;
u2=0*t2;
for m=N:-1:2
  u3=u2;
  u2=u1;
  u1=(S2(m)+2*ct2.*u2)-u3;
end
y(ind2)=y2+cos(t2).*u1;

y=reshape(y,shape_y);

%%
function [phi,lambda,u]=sphere2ellips(theta,lambda,r,e)
%SPHERE2ELLIPS converts the spherical coordinates (theta,lambda,r)
% of a 3-d point to ellipsoidal coordinates (phi,lambda,u).
% 'e' is the linear eccentricity of the confocal ellipses.
% e^2=a^2-b^2, where 'a', 'b' are the semi-axes.
% Forward stability for points with  u>e.
% Requirements: The arrays 'theta', 'lambda', 'r' must be of the same size;
% '0<=theta<=pi', '0<=lambda<2 pi', 'r>=0'; 'e' must be non-negative.

if (ndims(theta)~=ndims(lambda))||any(size(theta)~=size(lambda))||(ndims(theta)~=ndims(r))||any(size(theta)~=size(r))
  error('sphere2ellips:input','"theta", "lambda" and "r" must be of the same size');
end
shape_r=size(r);

if ~(isreal(e)&&(e>=0))
  error('sphere2ellips:e','"e" must be non-negative');
end


theta=theta(:);
lambda=lambda(:);
r=r(:);
if any(theta>pi)||any(theta<0), error('sphere2ellips:theta','"theta" must be between 0 and pi'); end
if any(lambda>=2*pi)||any(lambda<0), error('sphere2ellips:lambda','"lambda" must be between 0 and 2*pi'); end
if any(r<0), error('sphere2ellips:r','"r" must be non-negative'); end

s=(r.^2-e^2)/2;
u=sqrt(s+sqrt(s.^2+e^2*r.^2.*cos(theta).^2));
phi=atan2(sin(theta),sqrt(1+e^2./u.^2).*cos(theta));

phi=reshape(phi,shape_r);
lambda=reshape(lambda,shape_r);
u=reshape(u,shape_r);

%%
function y=kernel_values(ParKer,Kernel_y,x)
%KERNEL_VALUES computes the values of a needlet kernel considered as
% an even smooth function "supported" in a neighbourhood of the origin.
%
% The code uses 2*ParKer(6)-1 degree Lagrange interpolation at 
% equally spaced knots with step in ParKer(9)
% as needlet kernel values are given in 'Kernel_y'.
%
% INPUT:
% 1. ParKer -- see Parameters
% 2. Kernel_y  is the vector with kernel values at equally spaced nodes,
%    Kernel_y(k) contains the value at the node  (k-ParKer(6))*ParKer(9).
% 3. x  is an array with the values of the independent variable.
%
% OUTPUT: 
% 1. y  is an array with the values of the kernel
%    y is of the same size as  x.
%
% Notes. 
% 1. The code uses  ParKer(6), ParKer(7), ParKer(9). The dependence of
% the kernel on the other elements of  ParKer  is through 
% the values of  Kernel_y.
% 2. For x>ParKer(7) the code returns y=0.
% 3. The code assumes but does not check that x>=0.

% Version: October 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

sizey=size(x);
x=x(:);
y=zeros(length(x),1);

ind=(x<=ParKer(7));
x=x(ind);

k=floor(x/ParKer(9))+1;
d=x/ParKer(9)+1-k;
switch ParKer(6)
  case 2
    yy=(-d.*Kernel_y(k)+(d+1).*Kernel_y(k+1)*3).*(d-1).*(d-2) ...
        +(-(d-2).*Kernel_y(k+2)*3+(d-1).*Kernel_y(k+3)).*(d+1).*d;
    yy=yy/6;
  case 3
    yy=(-(d+1).*d.*Kernel_y(k)+(d+2).*d.*Kernel_y(k+1)*5 ...
        -(d+2).*(d+1).*Kernel_y(k+2)*10).*(d-1).*(d-2).*(d-3) ...
       +((d-2).*(d-3).*Kernel_y(k+3)*10-(d-1).*(d-3).*Kernel_y(k+4)*5 ...
        +(d-1).*(d-2).*Kernel_y(k+5)).*(d+2).*(d+1).*d;
    yy=yy/120;
  case 1
    yy=(1-d).*Kernel_y(k)+d.*Kernel_y(k+1);
  otherwise
    nu=ParKer(6);
    nu2=nu*2;
    len=length(x);
    YY=zeros(len,nu2);
    for n=1:nu2
     YY(:,n)=Kernel_y(k+n-1);
    end
    yy=zeros(len,1);
    for n=1:ParKer(6)
      mu=n;
      c=ones(len,1);
      for m=1:nu2
        if (m~=mu), c=c.*((d+nu-m)./(mu-m)); end
      end
      yy=yy+c.*YY(:,mu);
      mu=nu2+1-n;
      c=ones(len,1);
      for m=1:nu2
        if (m~=mu), c=c.*((d+nu-m)./(mu-m)); end
      end
      yy=yy+c.*YY(:,mu);
    end
end

y(ind)=yy;
y=reshape(y,sizey);

%%
function b=lagrange_basis(m,x)
%LAGRANGE_BASIS computes in  b  the values of Lagrange basis functions 
% for  m  integer knots  at the point  x.
% If m=2*k the knots are -k+1:k and 0<=x<=1
% If m=2*k+1 the knots are -k:k and -1/2<=x<=1/2

% Version: May 2014
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

x=x(:);
sizex=length(x);

b=zeros(sizex,m);
switch m
  case 10
    b(:,1)=-(x+3).*(x+2).*(x+1).*x.*(x-1).*(x-2).*(x-3).*(x-4).*(x-5)/362880;
    b(:,2)=(x+4).*(x+2).*(x+1).*x.*(x-1).*(x-2).*(x-3).*(x-4).*(x-5)/40320;
    b(:,3)=-(x+4).*(x+3).*(x+1).*x.*(x-1).*(x-2).*(x-3).*(x-4).*(x-5)/10080;
    b(:,4)=(x+4).*(x+3).*(x+2).*x.*(x-1).*(x-2).*(x-3).*(x-4).*(x-5)/4320;
    b(:,5)=-(x+4).*(x+3).*(x+2).*(x+1).*(x-1).*(x-2).*(x-3).*(x-4).*(x-5)/2880;
    b(:,6)=(x+4).*(x+3).*(x+2).*(x+1).*x.*(x-2).*(x-3).*(x-4).*(x-5)/2880;
    b(:,7)=-(x+4).*(x+3).*(x+2).*(x+1).*x.*(x-1).*(x-3).*(x-4).*(x-5)/4320;
    b(:,8)=(x+4).*(x+3).*(x+2).*(x+1).*x.*(x-1).*(x-2).*(x-4).*(x-5)/10080;
    b(:,9)=-(x+4).*(x+3).*(x+2).*(x+1).*x.*(x-1).*(x-2).*(x-3).*(x-5)/40320;
    b(:,10)=(x+4).*(x+3).*(x+2).*(x+1).*x.*(x-1).*(x-2).*(x-3).*(x-4)/362880;
  case 8
    b(:,1)=-(x+2).*(x+1).*x.*(x-1).*(x-2).*(x-3).*(x-4)/5040;
    b(:,2)=(x+3).*(x+1).*x.*(x-1).*(x-2).*(x-3).*(x-4)/720;
    b(:,3)=-(x+3).*(x+2).*x.*(x-1).*(x-2).*(x-3).*(x-4)/240;
    b(:,4)=(x+3).*(x+2).*(x+1).*(x-1).*(x-2).*(x-3).*(x-4)/144;
    b(:,5)=-(x+3).*(x+2).*(x+1).*x.*(x-2).*(x-3).*(x-4)/144;
    b(:,6)=(x+3).*(x+2).*(x+1).*x.*(x-1).*(x-3).*(x-4)/240;
    b(:,7)=-(x+3).*(x+2).*(x+1).*x.*(x-1).*(x-2).*(x-4)/720;
    b(:,8)=(x+3).*(x+2).*(x+1).*x.*(x-1).*(x-2).*(x-3)/5040;
  case 6
    b(:,1)=-(x+1).*x.*(x-1).*(x-2).*(x-3)/120;
    b(:,2)=(x+2).*x.*(x-1).*(x-2).*(x-3)/24;
    b(:,3)=-(x+2).*(x+1).*(x-1).*(x-2).*(x-3)/12;
    b(:,4)=(x+2).*(x+1).*x.*(x-2).*(x-3)/12;
    b(:,5)=-(x+2).*(x+1).*x.*(x-1).*(x-3)/24;
    b(:,6)=(x+2).*(x+1).*x.*(x-1).*(x-2)/120;
  case 5
    b(:,1)=(x+1).*x.*(x-1).*(x-2)/24;
    b(:,2)=-(x+2).*x.*(x-1).*(x-2)/6;
    b(:,3)=(x+2).*(x+1).*(x-1).*(x-2)/4;
    b(:,4)=-(x+2).*(x+1).*x.*(x-2)/6;
    b(:,5)=(x+2).*(x+1).*x.*(x-1)/24;
  case 4
    b(:,1)=-x.*(x-1).*(x-2)/6;
    b(:,2)=(x+1).*(x-1).*(x-2)/2;
    b(:,3)=-(x+1).*x.*(x-2)/2;
    b(:,4)=(x+1).*x.*(x-1)/6;
  case 3
    b(:,1)=x.*(x-1)/2;
    b(:,2)=-(x+1).*(x-1);
    b(:,3)=(x+1).*x/2;
  case 2
    b(:,1)=1-x;
    b(:,2)=x;
  case 1
    b(:,1)=1;
end

function [phig,re]=gd2gc(phi,ht,ae,b)

%      subroutine gd2gc(phi,ht,ae,b,phig,re)
%     CONVERTS COORDINATES FROM GEODETIC (phi,ht) TO GEOCENTRIC (phig,re)
%
% Remark. phi and phig are geograpic coordinates, i.e. angular distances to
% the equator (not to the notrh pole)!!!

%       ae = SEMI-MAJOR AXIS .....................(m) 
%       b  = SEMI-MINOR AXIS .....................(m) 

if ~(size(phi)==size(ht)), error('GC2GE:phi_ht','phi and ht must be of the same size'); end

e2 = (ae^2-b^2)/(ae^2);
u = sin(phi);
t = cos(phi);
en = ae./sqrt(1-e2*u.^2);
rho = (en + ht).*t;
z = (en*(1-e2) + ht).*u;
phig = atan2(z,rho);
re = sqrt(rho.^2 + z.^2);

