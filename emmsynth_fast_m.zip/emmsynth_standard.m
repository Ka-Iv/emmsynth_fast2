function emmsynth_standard
%EMMSYNTH_STANDARD computes and writes in a file 
% the values of the magnetic field gradient at scattered points 
% by the standard algorithm based on the EMM2015 or EMM2017 coefficients 
% and compares these values with the output of EMMSYNTH_FAST:
% given in 'scattered_points_values.dat'.
%
% INPUT: 
% 1. free format files
%    'EMM2015.COF' and 'EMM2015SV.COF' for Enhanced Magnetic Model EMM2015 or
%    'EMM2017.COF' and 'EMM2017SV.COF' for Enhanced Magnetic Model EMM2017.
%    with the model coefficients
% 2. free format file 'scattered_points_values.dat' with point's geodetic
%    latitude, longitude, (in degrees), height above the reference 
%    ellipsoid (in meters) and the value of the 10 magnetic field components 
%    computed by EMMSYNTH_FAST.
% 3. The chosen magnetic model.
% 4. The parameter 'year' when the model is computed.
%
% OUTPUT: 
% 1. free format file 'scattered_points_values_standard.dat' with point's 
%    geodetic latitude, longitude, (in degrees), height (in meters) 
%    and the values of the 10 magnetic field components evaluated by 
%    EMMSYNTH_STANDARD.
% 2. On screen statistics, including the 'Maximal absolute errors'.
%
% Notes.
% 1. The code applies different algorithms compared to the standard EMM 
%    code in the computation of 'Xprime' and 'Yprime'. 
%    These algorithms are stable all over the sphere including the poles.
% 2. The fields in every row of 'scattered_points_values.dat' and
%    'scattered_points_values_standard.dat' contain the values of the
%    the magnetic field gradient elements given in  'component'. 'phi' and 
%    'lambda' are geodetic geographic latitude and longitude (in degrees), 
%    'height' is the height above the reference ellipsoid (in meters).
%
% Version: November 2018
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

%% model and year input and check
model=input('Which model to use? (Enter 1 for EMM2015 or 2 for EMM2017): ');
switch model
  case 1
    modeldegree=740;
    s1='EMM2015.COF';
    s1SV='EMM2015SV.COF';
    year0=2015;
    year1=2020;
  case 2
    modeldegree=790;
    s1='EMM2017.COF';
    s1SV='EMM2017SV.COF';
    year0=2017;
    year1=2022;
  otherwise
      error('emmsynth_standard:model','wrong input"');
end

year=input('Enter decimal year for geomagnetic computations: ');
if (year<year0)||(year>year1)
  error('emmsynth_standard:year',['The year must be decimal number between ',num2str(year0),' and ',num2str(year1)]);
end
dt=year-year0;


time0=clock;

component={'phi','lambda','height',...
  'Xprime:                 ',...
  'Yprime:                 ',...
  'Zprime:                 ',...
  'North component X:      ',...
  'East component Y:       ',...
  'Down component Z:       ',...
  'Horizontal intensity H: ',...
  'Total intensity F:      ',...
  'Inclination I:          ',...
  'Declination D           '};


%% Earth constants
% wgs84_constants
ae = 6378137.0; 
inv_flat=298.257223563;
be = ae*(1-1/inv_flat);

am=6371200; %m; geomagnetic reference radius

%% scattered points for solid spherical polynomial evaluation
time1=clock;
s2='scattered_points_values.dat'; %scattered points input file name
pt=dlmread(s2);
npt=size(pt,1);
% checking point geodetic coordinates
if ~isreal(pt)
  error('emmsynth_standard:pZ','point coordinates must be real');
end
if (any(pt(:,1)<-90))||(any(pt(:,1)>90))
  error('emmsynth_standard:pt','latitude must be between -90 and 90 degrees');
end
if (any(pt(:,2)<-180))||(any(pt(:,2)>180))
  error('emmsynth_standard:pt','longitude must be between -180 and 180 degrees');
end
if (any(pt(:,3)<-415))||(any(pt(:,3)>1000000))
  error('emmsynth_standard:pt','hight must be between -415 m and 1,000,000 m');
end

values=zeros(npt,13); % output array
values(:,1:3)=pt(:,1:3);

point=zeros(npt,3); % work array

point(:,2)=pt(:,2)*pi/180;
ind=point(:,2)<0;
point(ind,2)=point(ind,2)+2*pi;

phi=pt(:,1)*pi/180;
[phiprime,point(:,3)]=gd2gc(phi,pt(:,3),ae,be);
point(:,1)=pi/2-phiprime; %co-latitude

point(:,3)=am./point(:,3);

TTime1=etime(clock,time1); %coordinate transformation time

%% Read spherical harmonic geomagnetic model
time2=clock;

N=modeldegree;
N1=N+1;
[cnm, snm]=read_coef0(s1,N);
NSV=15;
[cnmw, snmw]=read_coef0(s1SV,NSV);
NSV1=NSV+1;
cnm(1:NSV1,1:NSV1)=cnm(1:NSV1,1:NSV1)+dt*cnmw;
snm(1:NSV1,1:NSV1)=snm(1:NSV1,1:NSV1)+dt*snmw;

TTime2=etime(clock,time2); %model read time

%% from Schmidt semi-normalized ALF to fully-normalized ALF
time3=clock;
cnm=cnm.*(((2*(0:N)'+1).^(-1/2))*ones(1,N1));
snm=snm.*(((2*(0:N)'+1).^(-1/2))*ones(1,N1));

%% Spherical coefficient formation

% Xprime
cnm1=zeros(N1);
snm1=zeros(N1);
cnm2=zeros(N1);
snm2=zeros(N1);
tmp=1;
for n=2:2
  mm=(1:n);
  w=realsqrt((n-mm).*(n+mm-1))/2;
  w(1)=w(1)*realsqrt(2);
  cnm1(n,1)=w(1)*cnm(n,2)*tmp;
  cnm1(n,n)=-w(n-1)*cnm(n,n-1)*tmp;
  snm1(n,1)=0;
  snm1(n,n)=0;
  cnm2(n,1)=w(1)*snm(n,2)*tmp;
  cnm2(n,n)=0;
  snm2(n,1)=0;
  snm2(n,n)=-w(n-1)*cnm(n,n-1)*tmp;
end
for n=3:N1
  snm(n,1)=0; %just in case this is not fulfilled
  mm=(1:n);
  w=realsqrt((n-mm).*(n+mm-1))/2;
  w(1)=w(1)*realsqrt(2);
  cnm1(n,1)=w(1)*cnm(n,2)*tmp;
  cnm1(n,2:n-1)=(w(2:n-1).*cnm(n,3:n)-w(1:n-2).*cnm(n,1:n-2))*tmp;
  cnm1(n,n)=-w(n-1)*cnm(n,n-1)*tmp;
  snm1(n,2:n-1)=(w(2:n-1).*snm(n,3:n)-w(1:n-2).*snm(n,1:n-2))*tmp;
  snm1(n,n)=-w(n-1)*snm(n,n-1)*tmp;
  cnm2(n,1)=w(1)*snm(n,2)*tmp;
  cnm2(n,2:n-1)=(w(2:n-1).*snm(n,3:n)+w(1:n-2).*snm(n,1:n-2))*tmp;
  cnm2(n,n)=w(n-1)*snm(n,n-1)*tmp;
  snm2(n,2:n-1)=(-w(2:n-1).*cnm(n,3:n)-w(1:n-2).*cnm(n,1:n-2))*tmp;
  snm2(n,n)=-w(n-1)*cnm(n,n-1)*tmp;
end

% Yprime
cnm3=zeros(N1);
snm3=zeros(N1);
cnm4=zeros(N1);
snm4=zeros(N1);
tmp=.5;
w=realsqrt((0:2*N1-1).*(1:2*N1))';
cnm3(1:N,1)=-realsqrt(2)*w(2:N1).*snm(2:N1,2);
cnm4(1:N,1)=realsqrt(2)*w(2:N1).*cnm(2:N1,2);
for m=2:N
  cnm3(m:N,m)=-w(m+m:m+N).*snm(m+1:N1,m+1);
  snm3(m:N,m)=w(m+m:m+N).*cnm(m+1:N1,m+1);
  cnm4(m:N,m)=w(m+m:m+N).*cnm(m+1:N1,m+1);
  snm4(m:N,m)=w(m+m:m+N).*snm(m+1:N1,m+1);
end
for m=3:N
  cnm3(m:N,m)=cnm3(m:N,m)-w(2:N-m+2).*snm(m+1:N1,m-1);
  snm3(m:N,m)=snm3(m:N,m)+w(2:N-m+2).*cnm(m+1:N1,m-1);
  cnm4(m:N,m)=cnm4(m:N,m)-w(2:N-m+2).*cnm(m+1:N1,m-1);
  snm4(m:N,m)=snm4(m:N,m)-w(2:N-m+2).*snm(m+1:N1,m-1);
end
ww=realsqrt((3:2:2*N1+1)'./(1:2:2*N1-1)')*ones(1,N1);
cnm3=(cnm3.*ww)*tmp;
cnm4=(cnm4.*ww)*tmp;
snm3=(snm3.*ww)*tmp;
snm4=(snm4.*ww)*tmp;

% Zprime
cnm5=-cnm.*((1:N1)'*ones(1,N1));
snm5=-snm.*((1:N1)'*ones(1,N1));

TTime3=etime(clock,time3); %coefficient transformation time

%% computing Xprime, Yprime, Zprime
time4=clock;

w1=solid_polynomial_values_scattered(point(:,1),point(:,2),point(:,3),cnm1,snm1,10^260);
w2=solid_polynomial_values_scattered(point(:,1),point(:,2),point(:,3),cnm2,snm2,10^260);
values(:,4)=(w1.*cos(point(:,2))+w2.*sin(point(:,2))).*point(:,3).^2;
w1=solid_polynomial_values_scattered(point(:,1),point(:,2),point(:,3),cnm3,snm3,10^260);
w2=solid_polynomial_values_scattered(point(:,1),point(:,2),point(:,3),cnm4,snm4,10^260);
values(:,5)=(w1.*cos(point(:,2))+w2.*sin(point(:,2))).*point(:,3).^3;
values(:,6)=solid_polynomial_values_scattered(point(:,1),point(:,2),point(:,3),cnm5,snm5,10^260).*point(:,3).^2;

%% computing quantities in the ellipsoidal reference frame

% rotating geocentric to ellipsoidal reference frame
dphi=(phiprime-phi);
cdphi=cos(dphi);
sdphi=sin(dphi);
values(:,7)=values(:,4).*cdphi-values(:,6).*sdphi;
values(:,8)=values(:,5);
values(:,9)=values(:,4).*sdphi+values(:,6).*cdphi;

% evaluating the remaining components of the field  
H2=values(:,7).^2+values(:,8).^2;
values(:,10)=realsqrt(H2);
values(:,11)=realsqrt(H2+values(:,9).^2);
values(:,12)=atan2(values(:,9),values(:,10));
values(:,13)=atan2(values(:,8),values(:,7));
TTime4=etime(clock,time4); %derived computation time

%% output

time5=clock;
s3='scattered_points_values_standard.dat'; %scattered points and values output file name
fid=fopen(s3,'wt');
fprintf(fid, [repmat('%20.14f',1,2),'%16.8f',repmat('%12.4f',1,8),repmat('%12.8f',1,2),'\n'], values');
fclose(fid);
TTime5=etime(clock,time5);

TTime0=etime(clock,time0); %Total time  

%% error calculation

difference=values-pt;

%modify Inclination error
ind1=difference(:,12)>0.99*pi;
difference(ind1,12)=difference(ind1,12)-pi;
ind2=difference(:,12)<-0.99*pi;
difference(ind2,12)=difference(ind2,12)+pi;
count=sum(ind1)+sum(ind2);
if (count>0)
  disp(['Number of points with modify Inclination error: ',num2str(count)])
end

%modify Declination error
ind1=(difference(:,13)>0.99*pi)&(difference(:,13)<1.01*pi);
difference(ind1,13)=difference(ind1,13)-pi;
ind2=(difference(:,13)<-0.99*pi)&(difference(:,13)>-1.01*pi);
difference(ind2,13)=difference(ind2,13)+pi;
ind3=difference(:,13)>1.98*pi;
difference(ind3,13)=difference(ind3,13)-2*pi;
ind4=difference(:,13)<-1.98*pi;
difference(ind4,13)=difference(ind4,13)+2*pi;
count=sum(ind1)+sum(ind2)+sum(ind3)+sum(ind4);
if (count>0)
  disp(['Number of points with modify Declination error: ',num2str(count)])
end

%% statistics

disp('---------------------------------------------------------------')
switch model
  case 1
    disp('        Program:  emmsynth_standard,       Model: EMM2015')
  case 2
    disp('        Program:  emmsynth_standard,       Model: EMM2017')
end
disp(['   Evaluation year:            = ' num2str(year)])
disp('---------------------------------------------------------------')
disp(['   Total time                  = ' num2str(TTime0) ' CPU seconds']);
disp(['   Coordinate load time        = ' num2str(TTime1) ' CPU seconds']);
disp(['   Model load time             = ' num2str(TTime2) ' CPU seconds']);
disp(['   Coefficient formation time  = ' num2str(TTime3) ' CPU seconds']);
disp(['   Synthesis time              = ' num2str(TTime4) ' CPU seconds']);
disp(['   Values write time           = ' num2str(TTime5) ' CPU seconds'])
disp(['   Total number of points      = ' num2str(npt)]);
disp(['   Execution time per point    = ' num2str(TTime4/npt) ' CPU seconds']);
disp(['   Retrieved points per second = ' num2str(npt/TTime4)])
disp('---------------------------------------------------------------')
disp('     Maximal absolute errors at the given scattered points')
disp('---------------------------------------------------------------')
for k=4:13
  disp([char(component(k)) num2str(max(abs(difference(:,k))))])
end
disp('---------------------------------------------------------------')


%%
function y=solid_polynomial_values_scattered(theta,lambda,ar,cnm,snm,gs)
% SOLID_POLYNOMIAL_VALUES_SCATTERED computes the values 
% of a solid spherical polynomial with coefficients in  cnm, snm
% at the points (theta,lambda,ar)
%
% INPUT
% 1. theta, lambda, ar  are arrays of equal length with the spherical
%   coordinates of the scattered points in the unit 3-d ball.
%   theta is co-latitude, lambda  is longitude,  
%   ar  is distance from the origin.
% 2. cnm, snm  are lower square matrixes of the same size
%   with the cosine and sine coefficients of the solid polynomial
% 3. gs is a global scaling factor for avoiding underflow in evaluating the
%   associated Legendre functions, say gs=10^260.
%
% OUTPUT
% 1. y  is a vector of the lenth of  theta  with the polynomial values
%
% Version: May 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

N1=size(cnm,1);
nmax=N1-1;
root2=realsqrt(1:2*nmax+5)';
KK1=length(theta);

kappa=zeros(KK1,N1);
kappa(:,1)=1;
for k=1:nmax
  kappa(:,k+1)=kappa(:,k).*ar;
end

Cmt=zeros(KK1,N1);
Smt=zeros(KK1,N1);
pmm=alfsect(nmax,gs,theta);

for m=1:N1
  p=alford(nmax,m-1,theta,pmm,root2);
  pk=p.*kappa;
  Cmt(:,m)=(pk*cnm(:,m));
  Smt(:,m)=(pk*snm(:,m));
end

lm=lambda*(0:nmax);
y=sum(Cmt.*cos(lm)+Smt.*sin(lm),2)/gs;

function pmm=alfsect(N,gs,theta)
%ALFSECT computes scaled point values of sectorial Associated Legendre Functions
%
% INPUT
% 1. N is the maximum order of the required ALFs
% 2. gs is a global scaling factor for avoiding underflow in evaluating the
%   Associated Legendre Functions, say gs=10^260.
% 3. theta is a vector with the co-latitudes
% 
% OUTPUT
% 1. pmm  is a matrix of size N+1 x (the lenth of  theta)  
% with the scaled values of sectorial ALF
%
% Notes. 
% 1. ALFSECT follows Fortran alfpsec.f code
% 2. The input degree 'N' must be less than or equal to 2700.
%
% Version: May 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

theta=theta(:);
K=length(theta);
zero=zeros(K,1);

N1 = N+1;
c=zeros(N1,1);
c(2) = realsqrt(3);
for n1 = 3:N1
  rn2 = (n1-1)*2;
  c(n1) = realsqrt(rn2+1)/realsqrt(rn2);
end

small = -200;
gslog = log10(gs);
u=sin(theta);

ind=(u<eps);
zero(ind)=1;

ind=(u>1-eps);
zero(ind)=N1;

ind=((u>eps)&(u<1-eps));
zero(ind)=round((small - gslog)./log10(u(ind))) + 1;

ind=(zero>N1);
zero(ind)=N1;

pmm=zeros(N1,K);

for k=1:K
  u=sin(theta(k));
  pmm(1,k)=gs;
  for nu=2:zero(k)
    pmm(nu,k)=c(nu)*u*pmm(nu-1,k);
  end
end

function p=alford(N,m,theta,pmm,root2)
%ALFSECT computes scaled point values of non-sectorial Associated Legendre
% Functions (ALF) for a given order 'm' and for all degrees from 'm' to 'N'
%
% INPUT
% 1. N  is the maximum degree of the required ALFs
% 2. m  is the order for which non-sectorial ALFs are to be computed
% 3. theta is a vector with the co-latitudes
% 4. pmm  is a matrix of size N+1 x (the lenth of  theta)  
%   with the scaled values of sectorial ALF
% 5. root2 is a work vector, root2=realsqrt(1:2*N+5)'
%
% OUTPUT
% 4. p  is a matrix of size (the lenth of  theta) x N+1
%   with the scaled values of non-sectorial ALF
%
% Notes. 
% 1. ALFORD follows Fortran alfpord.f code
% 2. The input degree 'N' must be less than or equal to 2700.
% 3. The input order 'm' must be less than or equal to the maximum
%   degree 'N'. 
% 4. Note that any global scaling of the computed ALFs enters through the
%   pre-computed sectorial values in 'pmm'.
%
% Version: May 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

if (N>2700), error('ALFORD:big_degree','Degree %g bigger than 2700',N); end
if (m>N), error('ALFORD:big_order','Order %g bigger than degree %g',m,N); end

N1 = N+1;
theta=theta(:);
K=length(theta);
tc=cos(theta);
p=zeros(K,N1);

p(:,m+1)=pmm(m+1,:)';
if (m<N)
  p(:,m+2)=root2(2*m+3)*tc.*p(:,m+1);
end
for n1=m+3:N1
  temp=root2(2*n1-1)/root2(n1-1+m)/root2(n1-1-m);
  a=root2(2*n1-3)*temp;
  b=root2(n1+m-2)*root2(n1-m-2)*temp/root2(2*n1-5);
  p(:,n1)=a*tc.*p(:,n1-1)-b*p(:,n1-2);
end

function [phig,re]=gd2gc(phi,ht,ae,b)

%      subroutine gd2gc(phi,ht,ae,b,phig,re)
%     CONVERTS COORDINATES FROM GEODETIC (phi,ht) TO GEOCENTRIC (phig,re)
%
% Remark. phi and phig are geograpic coordinates, i.e. angular distances to
% the equator (not to the notrh pole)!!!

%       ae = SEMI-MAJOR AXIS .....................(m) 
%       b  = SEMI-MINOR AXIS .....................(m) 

if ~(size(phi)==size(ht)), error('GC2GE:phi_ht','phi and ht must be of the same size'); end

e2 = (ae^2-b^2)/(ae^2);
u = sin(phi);
t = cos(phi);
en = ae./sqrt(1-e2*u.^2);
rho = (en + ht).*t;
z = (en*(1-e2) + ht).*u;
phig = atan2(z,rho);
re = sqrt(rho.^2 + z.^2);

function [cnm, snm]=read_coef0(s1,nmax)

cnm=zeros(nmax+1);
snm=zeros(nmax+1);

% read coefficients
M=dlmread(s1);
for k=1:size(M,1)
  cnm(M(k,1)+1,M(k,2)+1)=M(k,3);
  snm(M(k,1)+1,M(k,2)+1)=M(k,4);
end
