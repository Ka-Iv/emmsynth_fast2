function emmsynth_init
%EMMSYNT_INIT evaluates the weighted regular grid values
% on multiple confocal ellipsoids of the magnetic field gradient
% and writes them in an unformatted data FORTRAN file 's3'.
% The gradient is defined via the magnetic model 
% coefficient files:
% 'EMM2015.COF' and 'EMM2015SV.COF' for Enhanced Magnetic Model EMM2015 or
% 'EMM2017.COF' and 'EMM2017SV.COF' for Enhanced Magnetic Model EMM2017.
%
% Version: November 2018
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

model=input('Which model to use? (Enter 1 for EMM2015 or 2 for EMM2017): ');
switch model
  case 1
    modeldegree=740;
    in1='EMM2015.COF';
    in2='EMM2015SV.COF';
    out1='emm2015_Xp.bin';
    out2='emm2015_Yp.bin';
    out3='emm2015_Zp.bin';
    out4='emm2015_XpSV.bin';
    out5='emm2015_YpSV.bin';
    out6='emm2015_ZpSV.bin';
  case 2
    modeldegree=790;
    in1='EMM2017.COF';
    in2='EMM2017SV.COF';
    out1='emm2017_Xp.bin';
    out2='emm2017_Yp.bin';
    out3='emm2017_Zp.bin';
    out4='emm2017_XpSV.bin';
    out5='emm2017_YpSV.bin';
    out6='emm2017_ZpSV.bin';
  otherwise
      error('emmsynth_init:model','wrong input"');
end
time0=clock;
TTime1=0;
TTime2=0;
TTime3=0;
TTime4=0;

%% Earth constants
% wgs84_constants
ae = 6378137.0; %m
inv_flat=298.257223563;
be = ae*(1-1/inv_flat);
E=realsqrt((ae-be)*(ae+be));

am=6371200; %m; geomagnetic reference radius

% displacement for the lowest Earth surface point wrt reference ellipsoid
db=-417;         %reference ellipsoid displacement in meters $b_0=b_e-417$
b0=be+db; 

terms_small=40;

%% nodal set
NN=740; %parameter for the nodal set

tau=2;
ndelta1=9; 
ndelta2=9; 

%% regular grid dimensions
KK=round((1+tau/2)*NN)+1;  
LL2=round((1+tau/2)*NN);
LL=2*LL2;   
weight=1/((KK-1)*LL2);           

phi=(0:KK-1)'*pi/(KK-1);         
lambda=(0:LL-1)'*2*pi/LL;
lambda0=ones(KK,1)*lambda';

%% extended values parameters

% extended dimensions
KKext=KK+2*ndelta1-1;  
LLext=LL+2*ndelta2-1;

%% generating heights
h=0.020124185;
NumHeights=45;

v=1-((0:NumHeights-1)*h).^4/4;
heights=b0*(1./v-1);  % heights in meters

disp('number of rows   number of columns   number of ellipsoids')
disp([KKext,LLext,NumHeights])

%% evaluation of geocentric magnetic quantities

for tipp={'X', 'XSV', 'Y', 'YSV', 'Z', 'ZSV'}
  tip=char(tipp);
  switch tip
    case 'X'
      N=modeldegree;
      s1=in1;
      s3=out1;
      chi=-1;
    case 'XSV'
      N=15;
      s1=in2;
      s3=out4;
      chi=-1;
    case 'Y'
      N=modeldegree;
      s1=in1;
      s3=out2;
      chi=-1;
    case 'YSV'
      N=15;
      s1=in2;
      s3=out5;
      chi=-1;
    case 'Z'
      N=modeldegree;
      s1=in1;
      s3=out3;
      chi=1;
    case 'ZSV'
      N=15;
      s1=in2;
      s3=out6;
      chi=1;
    otherwise
      error('emmsynth_init:tip','wrong value of "tip"');
  end

  N1=N+1;
  Ne=N+30;
  Ne1=Ne+1;

%% Ellipsoidal harmonic series coefficients

%% Read spherical harmonic geomagnetic model
  time1=clock;
  [cnm, snm]=read_coef0(s1,N);
  TTime1=TTime1+etime(clock,time1);

%% Modify spherical harmonic geomagnetic model
  time2=clock;

% from Schmidt semi-normalized ALF to fully-normalized ALF
  cnm=cnm.*(((2*(0:N)'+1).^(-1/2))*ones(1,N1));
  snm=snm.*(((2*(0:N)'+1).^(-1/2))*ones(1,N1));

% from reference sphere with radius 'am' to reference sphere with radius 'ae'
  arat   = am/ae;
  tmp=arat;
  for n =2:N1
    tmp=tmp*arat;
    cnm(n,:)=cnm(n,:)*tmp;
    snm(n,:)=snm(n,:)*tmp;
  end
    
%% Spherical coefficient formation
  switch tip
    case {'X', 'XSV'}
      cnm1=zeros(N1);
      snm1=zeros(N1);
      cnm2=zeros(N1);
      snm2=zeros(N1);
      tmp=1;
      for n=2:2
        mm=(1:n);
        w=realsqrt((n-mm).*(n+mm-1))/2;
        w(1)=w(1)*realsqrt(2);
        cnm1(n,1)=w(1)*cnm(n,2)*tmp;
        cnm1(n,n)=-w(n-1)*cnm(n,n-1)*tmp;
        snm1(n,1)=0;
        snm1(n,n)=0;
        cnm2(n,1)=w(1)*snm(n,2)*tmp;
        cnm2(n,n)=0;
        snm2(n,1)=0;
        snm2(n,n)=-w(n-1)*cnm(n,n-1)*tmp;
      end
      for n=3:N1
        snm(n,1)=0; 
        mm=(1:n);
        w=realsqrt((n-mm).*(n+mm-1))/2;
        w(1)=w(1)*realsqrt(2);
        cnm1(n,1)=w(1)*cnm(n,2)*tmp;
        cnm1(n,2:n-1)=(w(2:n-1).*cnm(n,3:n)-w(1:n-2).*cnm(n,1:n-2))*tmp;
        cnm1(n,n)=-w(n-1)*cnm(n,n-1)*tmp;
        snm1(n,2:n-1)=(w(2:n-1).*snm(n,3:n)-w(1:n-2).*snm(n,1:n-2))*tmp;
        snm1(n,n)=-w(n-1)*snm(n,n-1)*tmp;
        cnm2(n,1)=w(1)*snm(n,2)*tmp;
        cnm2(n,2:n-1)=(w(2:n-1).*snm(n,3:n)+w(1:n-2).*snm(n,1:n-2))*tmp;
        cnm2(n,n)=w(n-1)*snm(n,n-1)*tmp;
        snm2(n,2:n-1)=(-w(2:n-1).*cnm(n,3:n)-w(1:n-2).*cnm(n,1:n-2))*tmp;
        snm2(n,n)=-w(n-1)*cnm(n,n-1)*tmp;
      end
    case {'Y', 'YSV'}
      cnm1=zeros(N1);
      snm1=zeros(N1);
      cnm2=zeros(N1);
      snm2=zeros(N1);
      tmp=.5/arat;
      w=realsqrt((0:2*N1-1).*(1:2*N1))';
      cnm1(1:N,1)=-realsqrt(2)*w(2:N1).*snm(2:N1,2);
      cnm2(1:N,1)=realsqrt(2)*w(2:N1).*cnm(2:N1,2);
      for m=2:N
        cnm1(m:N,m)=-w(m+m:m+N).*snm(m+1:N1,m+1);
        snm1(m:N,m)=w(m+m:m+N).*cnm(m+1:N1,m+1);
        cnm2(m:N,m)=w(m+m:m+N).*cnm(m+1:N1,m+1);
        snm2(m:N,m)=w(m+m:m+N).*snm(m+1:N1,m+1);
      end
      for m=3:N
        cnm1(m:N,m)=cnm1(m:N,m)-w(2:N-m+2).*snm(m+1:N1,m-1);
        snm1(m:N,m)=snm1(m:N,m)+w(2:N-m+2).*cnm(m+1:N1,m-1);
        cnm2(m:N,m)=cnm2(m:N,m)-w(2:N-m+2).*cnm(m+1:N1,m-1);
        snm2(m:N,m)=snm2(m:N,m)-w(2:N-m+2).*snm(m+1:N1,m-1);
      end
      ww=realsqrt((3:2:2*N1+1)'./(1:2:2*N1-1)')*ones(1,N1);
      cnm1=(cnm1.*ww)*tmp;
      cnm2=(cnm2.*ww)*tmp;
      snm1=(snm1.*ww)*tmp;
      snm2=(snm2.*ww)*tmp;
    case {'Z', 'ZSV'}
      cnm1=-cnm.*((1:N1)'*ones(1,N1));
      snm1=-snm.*((1:N1)'*ones(1,N1));
  end

%% Ellipsoidal coefficient formation
  [cnmw,snmw]=jekeli_sphere2ellipsoid_coeff(cnm1,snm1,N,be,E,ae,terms_small);
  cnme1=cnmw(1:Ne1,1:Ne1);
  snme1=snmw(1:Ne1,1:Ne1);
  if (strcmp(tip,'X')||strcmp(tip,'XSV')||strcmp(tip,'Y')||strcmp(tip,'YSV'))
    [cnmw,snmw]=jekeli_sphere2ellipsoid_coeff(cnm2,snm2,N,be,E,ae,terms_small);
    cnme2=cnmw(1:Ne1,1:Ne1);
    snme2=snmw(1:Ne1,1:Ne1);
  end
  TTime2=TTime2+etime(clock,time2);

%% EHS values
  valueXext=zeros(KKext,LLext);
% open file  s3  for writing in machine format:IEEE floating point 
% with little-endian byte ordering and 64-bit long data type
  fid1 = fopen(s3, 'w', 'l');
% in FORTRAN replace with
% open(10,file=s3,form='unformatted',action='write',status='replace',iostat=ret_i)
  disp(tip)
  for nu=1:length(heights)
    time3=clock;
    u=b0+heights(nu);
    u0=u*ones(KK,1);
    [~,~,r1]=ellips2sphere(phi,zeros(KK,1),u0,E); %1
%     [theta1,lambda1,r1]=ellips2sphere(phi,zeros(KK,1),u0,E);
    valueX=ellipsoid_harmonic_series_grid(phi,LL,u,be,E,cnme1,snme1,10^260);
    if (strcmp(tip,'X')||strcmp(tip,'XSV')||strcmp(tip,'Y')||strcmp(tip,'YSV'))
      valueX=valueX.*cos(lambda0)+ellipsoid_harmonic_series_grid(phi,LL,u,be,E,cnme2,snme2,10^260).*sin(lambda0);
    end
    if (strcmp(tip,'Y')||strcmp(tip,'YSV'))
      valueX=valueX.*((am./r1).^2*ones(1,LL))*weight;
    else
      valueX=valueX.*((am./r1)*ones(1,LL))*weight;
    end
    
%   Spherical extension for  ParCub(1)==1
    valueXext(ndelta1:ndelta1+KK-1,ndelta2:ndelta2+LL-1)=valueX;
    valueXext(1:ndelta1-1,ndelta2:ndelta2+LL2-1)=chi*valueX(ndelta1:-1:2,LL2+1:LL);
    valueXext(1:ndelta1-1,ndelta2+LL2:ndelta2+LL-1)=chi*valueX(ndelta1:-1:2,1:LL2);
    valueXext(ndelta1+KK:KK+2*ndelta1-1,ndelta2:ndelta2+LL2-1)=chi*valueX(KK-1:-1:KK-ndelta1,LL2+1:LL);
    valueXext(ndelta1+KK:KK+2*ndelta1-1,ndelta2+LL2:ndelta2+LL-1)=chi*valueX(KK-1:-1:KK-ndelta1,1:LL2);
    valueXext(:,1:ndelta2-1)=valueXext(:,LL+1:LL+ndelta2-1);
    valueXext(:,LL+ndelta2:LL+2*ndelta2-1)=valueXext(:,ndelta2:2*ndelta2-1);
    TTime3=TTime3+etime(clock,time3);
%
    time4=clock;
    fwrite(fid1, KKext*LLext*8, 'uint32');
    fwrite(fid1, valueXext, 'double');
    fwrite(fid1, KKext*LLext*8, 'uint32');
%   in FORTRAN replace with
%   write(10), ((valuexext(k1,k2), k1=1,kkext), k2=1,llext)
    TTime4=TTime4+etime(clock,time4);

    disp([nu, heights(nu), max(max(abs(valueX)))/weight])
  end
%
  fclose(fid1);
% in FORTRAN replace with
% close(10)
%
end %for tipp=['X' 'XSV' 'Y' 'YSV' 'Z' 'ZSV']

TTime0=etime(clock,time0);

%% output2
disp('---------------------------------------------------------------')
switch model
  case 1
    disp('        Program:  emmsynth_init,       Model: EMM2015')
  case 2
    disp('        Program:  emmsynth_init,       Model: EMM2017')
end
disp('---------------------------------------------------------------')
disp(['  Total time                  = ' num2str(TTime0) ' CPU seconds'])
disp(['  Coefficients load time      = ' num2str(TTime1) ' CPU seconds'])
disp(['  Coefficients formation time = ' num2str(TTime2) ' CPU seconds'])
disp(['  Synthesis time              = ' num2str(TTime3) ' CPU seconds'])
disp(['  Values write time           = ' num2str(TTime4) ' CPU seconds'])
disp('---------------------------------------------------------------')


%%
function [cnmE,snmE]=jekeli_sphere2ellipsoid_coeff(cnmS,snmS,N,b,E,R,terms)
%JEKELI_SPHERE2ELLIPSOID_COEFF computes the ellipsoidal harmonic coefficients of
% a harmonic function given by its spherical harmonic coefficients.
% The coefficients are computed via Jekeli transform for the approximate identity
% $\sum_{n=0}^N \sum_{m=0}^n (a/r)^{n+1}
% (cnmS_{nm}\cos(m\lambda)+snmS_{nm}\sin(m\lambda)\tilde{P}_{nm}(\theta)
% = \sum_{n=0}^{N+2 terms} \sum_{m=0}^n \tilde{Q}_{nm}(iu/E)/\tilde{Q}_{nm}(ib/E) 
% (cnmE_{nm}\cos(m\lambda)+snmE_{nm}\sin(m\lambda)\tilde{P}_{nm}(\phi)$,
% where (theta,lambda,r) and (phi,lambda,u) are the spherical and ellipsoidal
% harmonic coordinates of a point in $R^3$.
%
% INPUT
% 1. 'cnmS', 'snmS'  are lower square matrices with N+1 rows holding
%    the cosine and sine spherical coefficients.
% 2. 'N' is the degree of the spherical harmonic series.
% 3. 'b' and 'E' are semi-minor axis and the linear eccentricity of the
%    reference ellipsoid.
% 4. 'R' is the radius of the reference sphere.
% 5. 'terms' is a parameter for function 'lambda_small'.
%
% OUTPUT
% 1. 'cnmE', 'snmE'  are lower square matrices with N+2*terms+1 rows holding
%    the cosine and sine ellipsoidal harmonic coefficients.
%
% Notes.
% 1. The code requires functions 'lambda_small' and 'hypergeometric21_alf4'.
% 2. Parameter '18' in 'hypergeometric21_alf4' is determined for the Earth
%    ellipsoid.

% Version: October 2015
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

cnmE=zeros(N+2*terms+1);
snmE=zeros(N+2*terms+1);
z2=(E/b)^2;

for m=0:N
  nu=(0:N+2*terms)';
  S=(1+z2)^(m/2)*(R/b).^(nu+1).*hypergeometric21_alf4(N+2*terms,m,-z2,18);

  coefSc=zeros(N+2*terms+1,1);
  coefSs=coefSc;
  coefEc=coefSc;
  coefEs=coefSc;
  coefSc(1:N+1)=cnmS(:,m+1);
  coefSs(1:N+1)=snmS(:,m+1);

  for n=m:N+2*terms
    w=min(floor((n-m)/2),terms-1);
    x1=lambda_small(n,m,E/R,terms);
    x2=S(n+1)*x1(1:w+1)';
    coefEc(n+1)=x2*coefSc(n+1:-2:n+1-2*w);
    coefEs(n+1)=x2*coefSs(n+1:-2:n+1-2*w);
  end
  cnmE(:,m+1)=coefEc;
  snmE(:,m+1)=coefEs;
end

%%
function y=hypergeometric21_alf4(N,m,z,degree)
%HYPERGEOMETRIC21_ALF4 computes the HG series for ALF of the second kind 
% 2F1((n+m+1)/2,(n+m+2)/2;(2n+3)/2;z)
% using linear and quadratic transformations.
% The code differs from 'hypergeometric21_alf2' by using combination of
% methods 2 and 3, as 'N', 'm', 'z' are numbers.
% 'N' defines the array n=(0:N)' of spherical degrees. max(max(abs(z)))<1.
%
% Use degree=18 for geopotential studies with N<=2300.

if (m<0), m=-m; end
if (N<0), error('hypergeometric21_alf3:N','"N" must be non-negative'); end

y=zeros(N+1,1);

% y=0 if n<m
if (N<m), return; end

%method 2 for m<=n<2*m
if (m~=0)
    n=(m:min(2*m-1,N))';
    alpha=.5*(n-m+1);
    beta=alpha+.5;
    gamma=n+1.5;
    g=exp(-log1p(-z)*m);
    z1=z;
    temp=0*n+1;
    wy=temp;
    for k=0:degree-1
      temp=temp.*(alpha+k).*(beta+k)./(gamma+k)*(z1/(k+1));
      wy=wy+temp;
    end
    y(n+1)=g*wy;
end
if (N<2*m), return; end

%method 3 for 2*m<=n
n=(2*m:N)';
alpha=m+.5;
beta=-m+.5;
gamma=n+1.5;
zlog=.5*log1p(-z);
z2=-expm1(zlog);
g=exp(-zlog*(m+.5)-log1p(-z2/2)*(n+.5));
z1=-z/(4-2*(z2+z));
temp=0*n+1;
wy=temp;
for k=0:degree-1
  temp=temp./(gamma+k)*(z1*(alpha+k)*(beta+k)/(k+1));
  wy=wy+temp;
end
y(n+1)=g.*wy;

%%
function y=lambda_small(n,m,x,terms)
%LAMBDA_SMALL is the $\lambda$ function of Jekeli transform, 1988,
% where $y(k+1)=\lambda_{n,m,k}$, x=E/a.
% 
% INPUT
% 1. 'n', 'm'  are integers satisfying 0 <= m <= n.
% 2. 'x' is real, x=E/a in the case of Earth reference sphere and ellipsoid
% 5. 'terms' is the lenth of the coefficient vector 'y'
%
% OUTPUT
% 1. 'y' is the coefficient vector of length 'terms'
%
% Notes.
% terms=40 cuts  lambda  at 10^{-25} for every 0<=m<=n<=2190 and x=E/a.

% Version: October 2015
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

y=zeros(terms,1);
if (abs(m)>n), return; end
y(1)=1;
w=floor((n-abs(m))/2);
w1=min(w,terms-1);
for k=1:w1
  tmp=realsqrt((n-m-2*k+1)*(n-m-2*k+2)*(n+m-2*k+1)*(n+m-2*k+2)*(2*n-4*k+1)/(2*n-4*k+5));
  y(k+1)=tmp/(2*k*(2*n-2*k+1))*x^2*y(k);
end

%%
function [theta,lambda,r]=ellips2sphere(phi,lambda,u,e)
%ELLIPS2SPHERE converts the ellipsoidal coordinates (phi,lambda,u)
% of a 3-d point spherical coordinates (theta,lambda,r).
% 'e' is the linear eccentricity of the confocal ellipses.
% e^2=a^2-b^2, where 'a', 'b' are the semi-axes.
% Forward stability for u>e.
% Requirements: The arrays 'phi', 'lambda', 'u' must be of the same size;
% '0<=phi<=pi', '0<=lambda<2 pi', 'u>=0'; 'e' must be non-negative.

if (ndims(phi)~=ndims(lambda))||any(size(phi)~=size(lambda))||(ndims(phi)~=ndims(u))||any(size(phi)~=size(u))
  error('ellips2sphere:input','"phi", "lambda" and "u" must be of the same size');
end
shape_u=size(u);

if ~(isreal(e)&&(e>=0))
  error('ellips2sphere:e','"e" must be non-negative');
end

phi=phi(:);
lambda=lambda(:);
u=u(:);
if any(phi>pi)||any(phi<0), error('ellips2sphere:phi','"phi" must be between 0 and pi'); end
if any(lambda>=2*pi)||any(lambda<0), error('ellips2sphere:lambda','"lambda" must be between 0 and 2*pi'); end
if any(u<0), error('ellips2sphere:u','"u" must be non-negative'); end

r=sqrt(u.^2+e^2*sin(phi).^2);
theta=atan2(sqrt(1+e^2./u.^2).*sin(phi),cos(phi));

theta=reshape(theta,shape_u);
lambda=reshape(lambda,shape_u);
r=reshape(r,shape_u);

%%
function y=ellipsoid_harmonic_series_grid(phi,L,u,b,E,cnm,snm,gs)
% ELLIPSOID_HARMONIC_SERIES_SCATTERED computes the values 
% of a finite ellipsoidal harmonic series at the grid
% with rows given by the elements of 'phi' and (0:L-1)*2*pi/L as columns
% on the ellipsoid with semi-minor axis 'u' and linear eccentricity 'E'.
% The coefficients in 'cnm', 'snm' are determined for the refference  
% confocal ellipsoid with semi-minor axis 'b'.
% The code follows 'sph_poly_values_grid', 
% as the coefficients 'cnm', 'snm' are accordingly modified.
%
% INPUT
% 1. 'phi' is a vectors with the ellipsoidal-harmonic compliment of reduced latitude
%   coordinate of the grid points on the ellipsoid with semi-minor axis 'u'.
% 2. 'L', 'u', 'b', 'E' are numbers, 'L' is integer, u>=0, b>0, E>0.
% 3. 'cnm', 'snm'  are lower square matrixes of the same size
%   with the cosine and sine coefficients of the ellipsoidal harmonic series
% 4. 'gs' is a global scaling factor for avoiding underflow in evaluating the
%   associated Legendre functions, say gs=10^260.
%
% OUTPUT
% 1. 'y'  is a vector of the lenth of  'phi'  with the series values
%
% Version: October 2015
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

N1=size(cnm,1);
N=N1-1;
phi=phi(:);
K=length(phi);
root2=realsqrt(1:2*N+5)';

% modification of the coefficients for the ellipsoidal harmonic case
rho=zeros(N1);
rho1=(b/u).^(1:N1)';
rho2=1;
tau=realsqrt((1+(E/u)^2)/(1+(E/b)^2));
for m=0:N
  work1=hypergeometric21_alf4(N,m,-(E/u)^2,18);
  work2=hypergeometric21_alf4(N,m,-(E/b)^2,18);
  rho(m+1:N1,m+1)=rho2*rho1(m+1:N1).*(work1(m+1:N1)./work2(m+1:N1));
  rho2=rho2*tau;
end
cnm=rho.*cnm;
snm=rho.*snm;

% series evaluation
y=zeros(K,L); %matrix with spherical polynomial values
Cmt=zeros(K,N1);
Smt=zeros(K,N1);

pmm=alfsect(N,gs,phi);

for m=1:N1
  p=alford(N,m-1,phi,pmm,root2);
  Cmt(:,m)=(p*cnm(:,m));
  Smt(:,m)=(p*snm(:,m));
end

for k=1:K
  X=complex(pre_fft(Cmt(k,:)',L,1),pre_fft(Smt(k,:)',L,-1));
  y(k,:)=real(fft(X))/gs;
end

%%
function pmm=alfsect(N,gs,theta)
%ALFSECT computes scaled point values of sectorial Associated Legendre Functions
%
% INPUT
% 1. N is the maximum order of the required ALFs
% 2. gs is a global scaling factor for avoiding underflow in evaluating the
%   Associated Legendre Functions, say gs=10^260.
% 3. theta is a vector with the co-latitudes
% 
% OUTPUT
% 1. pmm  is a matrix of size N+1 x (the lenth of  theta)  
% with the scaled values of sectorial ALF
%
% Notes. 
% 1. ALFSECT follows Fortran alfpsec.f code
% 2. The input degree 'N' must be less than or equal to 2700.
%
% Version: May 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

theta=theta(:);
K=length(theta);
zero=zeros(K,1);

N1 = N+1;
c=zeros(N1,1);
c(2) = realsqrt(3);
for n1 = 3:N1
  rn2 = (n1-1)*2;
  c(n1) = realsqrt(rn2+1)/realsqrt(rn2);
end

small = -200;
gslog = log10(gs);
u=sin(theta);

ind=(u<eps);
zero(ind)=1;

ind=(u>1-eps);
zero(ind)=N1;

ind=((u>eps)&(u<1-eps));
zero(ind)=round((small - gslog)./log10(u(ind))) + 1;

ind=(zero>N1);
zero(ind)=N1;

pmm=zeros(N1,K);

for k=1:K
  u=sin(theta(k));
  pmm(1,k)=gs;
  for nu=2:zero(k)
    pmm(nu,k)=c(nu)*u*pmm(nu-1,k);
  end
end

%%
function p=alford(N,m,theta,pmm,root2)
%ALFSECT computes scaled point values of non-sectorial Associated Legendre
% Functions (ALF) for a given order 'm' and for all degrees from 'm' to 'N'
%
% INPUT
% 1. N  is the maximum degree of the required ALFs
% 2. m  is the order for which non-sectorial ALFs are to be computed
% 3. theta is a vector with the co-latitudes
% 4. pmm  is a matrix of size N+1 x (the lenth of  theta)  
%   with the scaled values of sectorial ALF
% 5. root2 is a work vector, root2=realsqrt(1:2*N+5)'
%
% OUTPUT
% 4. p  is a matrix of size (the lenth of  theta) x N+1
%   with the scaled values of non-sectorial ALF
%
% Notes. 
% 1. ALFORD follows Fortran alfpord.f code
% 2. The input degree 'N' must be less than or equal to 2700.
% 3. The input order 'm' must be less than or equal to the maximum
%   degree 'N'. 
% 4. Note that any global scaling of the computed ALFs enters through the
%   pre-computed sectorial values in 'pmm'.
%
% Version: May 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

if (N>2700), error('ALFORD:big_degree','Degree %g bigger than 2700',N); end
if (m>N), error('ALFORD:big_order','Order %g bigger than degree %g',m,N); end

N1 = N+1;
theta=theta(:);
K=length(theta);
tc=cos(theta);
p=zeros(K,N1);

p(:,m+1)=pmm(m+1,:)';
if (m<N)
  p(:,m+2)=root2(2*m+3)*tc.*p(:,m+1);
end
for n1=m+3:N1
  temp=root2(2*n1-1)/root2(n1-1+m)/root2(n1-1-m);
  a=root2(2*n1-3)*temp;
  b=root2(n1+m-2)*root2(n1-m-2)*temp/root2(2*n1-5);
  p(:,n1)=a*tc.*p(:,n1-1)-b*p(:,n1-2);
end

%%
function y=pre_fft(x,L,s)
%PRE_FFT transforms vector x of length N to vector y of length L
% so that:
% for $s=1$ we have $\sum_{m=1}^N x(m)\cos(2\pi(m-1)k)/L)
%   = \sum_{m=1}^L y(m)\exp(-2\pi i(m-1)k/L), k=1,2,\dots,L$;
% for $s=-1$ we have $\sum_{m=1}^N x(m)\sin(2\pi(m-1)k/L)
%   = i \sum_{m=1}^L y(m)\exp(-2\pi i(m-1)k/L), k=1,2,\dots,L$.
%
% INPUT
% 1. x is a N x 1 numerical vector
% 2. L is a positive integer
% 3. s is 1 or -1. For s=1 vector  x  contains the coefficients of a cosine
% series. For s=-1 vector  x  contains the coefficients of a sine series.
%
% OUTPUT
% 1. y is a L x 1 numerical vector
% 
% Notes.
%  1. The code prepares the coefficient vector  x  for FFT

% Version: May 2013
% Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg

y=zeros(L,1);
x=x(:);
N=length(x);
R=ceil(N/L)-1;
for r=0:R-1
  rL=r*L;
  y(1)=y(1)+x(rL+1);
  y(2:L)=y(2:L)+x((rL+2):(rL+L))/2;
  y(L:-1:2)=y(L:-1:2)+s*x((rL+2):(rL+L))/2;
end
RL=R*L;
y(1)=y(1)+x(RL+1);
y(2:N-RL)=y(2:N-RL)+x((RL+2):N)/2;
y(L:-1:RL+L-N+2)=y(L:-1:RL+L-N+2)+s*x((RL+2):N)/2;
if ~(s==1), y(1)=0; end

function [cnm, snm]=read_coef0(s1,nmax)

cnm=zeros(nmax+1);
snm=zeros(nmax+1);

% read coefficients
M=dlmread(s1);
for k=1:size(M,1)
  cnm(M(k,1)+1,M(k,2)+1)=M(k,3);
  snm(M(k,1)+1,M(k,2)+1)=M(k,4);
end

%%
% function y=func0(phi,u,a,b,E,gm,omega,x,tip)
% switch tip
%   case 'T'
%     y=ones(size(x));
%   case 'zeta'
%     y=1./normal_gravity(phi,u,a,b,E,gm,omega);
%   case {'Dg','dg'}
%     y=x;
%   case 'xi'
%     y=x./normal_gravity(phi,u,a,b,E,gm,omega);
%   case 'eta'
%     y=x.^2./normal_gravity(phi,u,a,b,E,gm,omega);
%   case 'Trr'
%     y=x.^2;
% end
% 
% %%
% function gamma=normal_gravity(phi,u,a,b,E,gm,omega)
% %NORMAL_GRAVITY computes the normal gravity at points with ellipsoidal
% % coordinates (phi,u), where 'phi' are the reduced co-latitudes
% % and 'u' are the semi-minor axes in meters of the congruent ellipsoids.
% %
% % INPUT:
% % 1. 'phi' is an array with the reduced co-latitudes
% % 2. 'u' is an array with the semi-minor axes (in meters)
% % 3. 'a' is the Earth semi-major axis (in meters)
% % 4. 'b' is the Earth semi-minor axis (in meters)
% % 5. 'E' is the Earth linear eccentricity (in meters)
% % 6. 'gm' is the Earth gravitational constant (m^3/s^2)
% % 7. 'omega' is the angular velocity of the Earth (rad/s)
% %
% % OUTPUT:
% % 1. 'gamma' is an array of the size of 'u' with the normal gravity (m/s^2)
% %
% % Notes:
% % 1. 'phi' and 'u' must be arrays of the same size.
% % 2. 0 <= phi <= pi, u>0.
% 
% % Version: October 2015
% % Author:  Kamen Ivanov,      Contact: kamen@math.bas.bg
% 
% sin_phi=sin(phi);
% sin_phi2=sin_phi.^2;
% cos_phi=cos(phi);
% cos_phi2=cos_phi.^2;
% ue2=u.^2+E^2;
% omega2=omega^2;
% 
% w=realsqrt((u.^2+E^2*cos_phi2)./ue2);
% q0=((1+3*b^2/E^2)*atan(E/b)-3*b/E)/2;
% q=((1+3*u.^2/E^2).*atan(E./u)-3*u/E)/2;
% q1=3*(1+u.^2/E^2).*(1-u/E.*atan(E./u))-1;
% 
% gamma_u=(-(gm./ue2+(omega2*a^2*E/q0)*(q1./ue2).*(cos_phi2-1/3)/2)+omega2*u.*sin_phi2)./w;
% gamma_phi=omega2*((a^2/q0)*q-ue2).*cos_phi.*sin_phi./w./realsqrt(ue2);
% gamma=realsqrt(gamma_u.^2+gamma_phi.^2);

